var alt_cur = ("init_shader_alts" in self? init_shader_alts: get_player_color(player));

/* colormapping template
var e = 0;
var r, g, b;
if !alt_cur repeat 8{
	r = get_color_profile_slot_r(32, e);
	g = get_color_profile_slot_g(32, e);
	b = get_color_profile_slot_b(32, e);
    set_character_color_slot(e, r, g, b);
    set_article_color_slot(e, r, g, b);
    e++;
}
//*/

#define set_outline_col(r, g, b)
static_colorO[32] = r/255;
static_colorO[33] = g/255;
static_colorO[34] = b/255;
if ("burned" in self && burned) || ("outline_color" in self && (outline_color[0] != 0 || outline_color[1] != 0 || outline_color[2] != 0)) return;
colorO[32] = r/255;
colorO[33] = g/255;
colorO[34] = b/255;