// attack_update

//B - Reversals
if (attack == AT_NSPECIAL || attack == AT_FSPECIAL || attack == AT_DSPECIAL || attack == AT_USPECIAL){
    trigger_b_reverse();
}
var window_end = floor(get_window_value(attack, window, AG_WINDOW_LENGTH) * ((get_window_value(attack, window, AG_WINDOW_HAS_WHIFFLAG) && !has_hit) ? 1.5 : 1));

if !hitstop switch attack{
    case AT_JAB:
    break;
}

#define set_window
/// set_window(win, t = 0;)
var win = argument[0];
var t = argument_count > 1 ? argument[1] : 0;;
window = win;
window_timer = t;

#define offset_hud
/// offset_hud(am, coeff = .2;)
var am = argument[0];
var coeff = argument_count > 1 ? argument[1] : .2;;
hud_offset = floor(lerp(hud_offset, am, coeff));

//written by supersonic, modified by bar-kun
#define spawn_base_dust
/// spawn_base_dust(x, y, name, dir = 0, angle = 0, win = -10, win_time = 0)
// spawn_base_dust(x, y, name)
// spawn_base_dust(x, y, name, ?dir, ?angle, ?window, ?window_timer)

// This function spawns base cast dusts. Names can be found below.
var dlen; //dust_length value
var dfx; //dust_fx value
var dfg; //fg_sprite value
var dust_color = 0;
var x = argument[0], y = argument[1], name = argument[2];
var dir = argument_count > 3 ? argument[3] : 0;
var angle = argument_count > 4 ? argument[4] : 0;
var win = argument_count > 5 ? argument[5] : -10;
var win_time = argument_count > 6 ? argument[6] : 0;

if (!hitpause && (win > 0 && win == window && win_time == window_timer || win == -10) ){ //spawns it whenever we want for 1 frame
    switch name{
        default: 
        case "dash_start":dlen = 21; dfx = 3; dfg = 2626; break;
        case "dash": dlen = 16; dfx = 4; dfg = 2656; break;
        case "jump": dlen = 12; dfx = 11; dfg = 2646; break;
        case "doublejump": 
        case "djump": dlen = 21; dfx = 2; dfg = 2624; break;
        case "walk": dlen = 12; dfx = 5; dfg = 2628; break;
        case "land": dlen = 24; dfx = 0; dfg = 2620; break;
        case "n_wavedash": dlen = 24; dfx = 0; dfg = 2620; dust_color = 1; break;
        case "wavedash": dlen = 16; dfx = 4; dfg = 2656; dust_color = 1; break;
        //
        //bar-kun additions (note: idk how fg_sprite work)
        //
        case "dattack": dlen = 22; dfx = 12; dfg = 0; break;
        case "b_bounce_bg": dlen = 10; dfx = 7; dfg = 0; break;
        case "b_bounce_fg": dlen = 14; dfx = 8; dfg = 0; break;
        case "s_bounce_bg": dlen = 18; dfx = 7; dfg = 0; break;
        case "s_bounce_fg": dlen = 19; dfx = 8; dfg = 0; break;
        case "doublejump_small": 
        case "djump_small": dlen = 21; dfx = 16; dfg = 0; break;
    }
    var newdust = spawn_dust_fx(x, y, asset_get("empty_sprite"), dlen);
    newdust.x = floor(x);
    newdust.y = floor(y);
    newdust.dust_fx = dfx; //set the fx id
    if (dfg != -1) newdust.fg_sprite = dfg; //set the foreground sprite

    newdust.dust_color = dust_color; //set the dust color

    if (dir != 0) newdust.spr_dir = dir; //set the spr_dir, if dir is 0 it will take the player's spr_dir
    else newdust.spr_dir = spr_dir;

    newdust.draw_angle = angle; //sets the angle of the dust sprite
    return newdust;
}
