if "animation_timer" not in self exit;
init_shader();

/* css button template
var cx = get_instance_x(cursor_id);
var cy = get_instance_y(cursor_id);

var bx = 0;
var by = 0;
var bw = 0;
var bh = 0;

var val = 0;
if button_timer button_timer--;
else{
	if cx == clamp(cx + bx - x, 0, bw) && cy == clamp(cy + by - y, 0, bh){
		suppress_cursor = 1;
		button_timer = -1;
		if menu_a_pressed{
			button_timer = 10;
			button = (button+1)%(options+1);
			//sound_play(sound_get(""));
		}
	}else button_timer = 0;
}
set_synced_var(player, button);
//*/