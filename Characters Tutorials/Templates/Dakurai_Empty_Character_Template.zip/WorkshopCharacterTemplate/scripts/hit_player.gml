//hit

switch my_hitboxID.attack{
	case AT_JAB:
	break;
}

/* custom hit fx auto layer
with hit_fx_obj if player_id == other && array_find_index([other., other.], hit_fx)+1 depth = other.depth+1;
//*/