///#args attack...

if !move_cooldown[attack] switch attack{
    case AT_JAB:
    break;
}