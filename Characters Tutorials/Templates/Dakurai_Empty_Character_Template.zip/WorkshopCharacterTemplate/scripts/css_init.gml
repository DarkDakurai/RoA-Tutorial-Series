animation_timer = 0;
alpha_alt = 0;
prev_alt = get_player_color(player);
anim_timer = 0;
init_shader_alts = get_player_color(player);

init_shader();

alt_name = [
	"unnamed",
	"unnamed",
	"unnamed",
	"unnamed",
	"unnamed",
	"unnamed",
	"unnamed",
	"unnamed",
	"unnamed",
	"unnamed",
	"unnamed",
	"unnamed",
	"unnamed",
	"unnamed",
	"unnamed",
	"unnamed",
	"unnamed",
	"unnamed",
	"unnamed",
	"unnamed",
	"unnamed",
	"unnamed",
	"unnamed",
	"unnamed",
	"unnamed",
	"unnamed",
	"unnamed",
	"unnamed",
	"unnamed",
	"unnamed",
	"unnamed",
	"unnamed"
];

/* colormap template
sprite_change_offset("hud", 0, -2);
sprite_change_offset("corr_hud", 0, -2);
sprite_change_offset("hud_hurt", 0, -2);
sprite_change_offset("corr_hud_hurt", 0, -2);

var dat = (!init_shader_alts? "corr_": "")
set_ui_element(UI_WIN_PORTRAIT, sprite_get(dat + "portrait"));
set_ui_element(UI_WIN_SIDEBAR, sprite_get(dat + "result_small"));
set_ui_element(UI_CHARSELECT, sprite_get(dat + "charselect"));
set_ui_element(UI_HUD_ICON, sprite_get(dat + "hud"));
set_ui_element(UI_HUDHURT_ICON, sprite_get(dat + "hud_hurt"));
set_ui_element(UI_OFFSCREEN, sprite_get(dat + "offscreen"));
//*/

/* css button
options = 2;
if get_synced_var(player) > options set_synced_var(player, 0);
button = get_synced_var(player);
button_timer = 0;

//*/