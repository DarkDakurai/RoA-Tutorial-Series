///#args attack
//  ^ this line up here makes gmedit not freak out

//set_attack.gml
is_attacking = true;